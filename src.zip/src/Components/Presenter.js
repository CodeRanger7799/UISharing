import React from 'react'
import { Link } from "react-router-dom";

function Presenter(props) {
    const handleSearch = () => {
      console.log(document.getElementById("searchParameter").value);
    };

    return (
      <div>
        <div className="container-menu-options">
          <p> Presenter Dashboard</p>
        </div>
        <div class="navbar-merchant">
          <select name="selectParam">
            <option value="Presenter Id" selected >Presenter ID</option>
            <option value="Short Name">Short Name</option>
            <option value="Organization Id">Organization Id</option>
            <option value="Organization Name">Organization Name</option>
          </select>
          <input type="text" placeholder="Search.." name="searchParameter" id="searchParameter"/>
          <button type="submit" onClick={handleSearch}>
            <i class="fa fa-search"></i>
          </button>
          <Link to="/PresenterAdd" className='navbar-merchant-Link'>Add</Link>
          <Link to="/" className='navbar-merchant-Link'>Edit Basic Details </Link>
          <div class="dropdown-menu">
       <button class="dropbtn-menu">FTP Accounts
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
          <div class="dropdown-menu">
       <button class="dropbtn-menu">Features
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
        </div>
      <div className="table-container">
        <table>
          <tr>
            <th>Presenter ID</th>
            <th>Short Name</th>
            <th>Organization Id</th>
            <th>Organization Name</th>
          </tr>
          <tr>
              <td><Link to='/'>122334</Link></td>
              <td>Dom</td>
              <td>1001</td>
              <td>Dominos</td>
          </tr>
          <tr>
              <td><Link to='/'>445566 </Link></td>
              <td>k</td>
              <td>2001</td>
              <td>KFC</td>
          </tr>
        </table>
      </div>
      </div>
    );
  }

export default Presenter