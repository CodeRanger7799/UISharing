import React from 'react'
import {Link} from 'react-router-dom'


function Opportunity(props){

  const handleSearch = () =>
  {
    console.log(document.getElementById('searchParameter').value)
  }

    return (
      
    <div>
     <div className='container-menu-options'>
         <p> Opportunity Dashboard</p>
     </div>
     <div class="navbar-merchant">
        <select name='selectParam'>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        </select>
     <input type="text" placeholder="Search.." name='searchParameter' id='searchParameter'/>
     <button type="submit" onClick = {handleSearch}><i class="fa fa-search"></i></button>  
     <Link to="/Parent" className='navbar-opportunity-Link'>Add</Link>
   </div>
   <div className="table-container">
  <table>
    <tr>
      <th>Opportunity ID</th>
      <th>Merchant Name</th>
      <th> Country</th>
      <th>Merchant Category Code</th>
      <th>Sub Merchant Name</th>
      <th>Status</th>
    </tr>
    {/* {props.merchantList.map(data => (
       <tr>
       <td>{data.mid}</td>
        <td>{data.merchantName}</td>
        <td>{data.organizationId}</td>
        <td>{data.processingGroupId}</td>
        <td>{data.billingProfileId}</td>
        <td>{data.shortName}</td>
        <td>{data.legalName}</td>
        <td>{data.city}</td>
         <td>{data.state}</td>
        <td>{data.country}</td>
        <td>{data.phoneNumber}</td>
        <td>{data.cardAcceptorTaxId}</td>
        <td>{data.merchantCategoryCode}</td>
        <td>{data.subMerchantName}</td>
        <td>{data.subMerchantUrl}</td>
     </tr>
    ))} */}
    <tr>
        <td><Link to='/'>122334</Link></td>
        <td>Zoopgo</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>KYC</td>
    </tr>
    <tr>
        <td><Link to='/'>990988 </Link></td>
        <td>BigBazar Salt Lake</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>Underwriting</td>
    </tr>
  </table>
</div>
   </div>
 
  
    )
}

export default Opportunity