import React,{Component} from 'react'
import {Link} from 'react-router-dom'

class HomeDashboard extends Component{
    render(){
        return (
            <div>
                <div className='container-menu-options'>
                 <p> Home Dashboard</p>
                </div>
                <div class="container-card">
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = "/Parent"><i class="material-icons">&#xe7fe;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Opportunity</p>
                    </div>
                </div>
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = '/MerchantSignup'><i class="material-icons">&#xe89c;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Merchant</p>
                    </div>
                </div>
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = '/AddProcessingGroup'><i class="material-icons">&#xe89c;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Processing Group</p>
                    </div>
                </div> 
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = '/AddBillingProfile'><i class="material-icons">&#xe89c;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Billing Profile</p>
                    </div>
                </div> 
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = '/AddOrganization'><i class="material-icons">&#xe89c;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Organization</p>
                    </div>
                </div>  
                <div class="items">
                    <div class="icon-wrapper">
                    <Link to = '/PresenterAdd'><i class="material-icons">&#xe89c;</i></Link>
                    </div>
                    <div class="project-name">
                    <p>Add Presenter</p>
                    </div>
                </div> 
                </div>

            </div>
        )
    }

}

export default HomeDashboard