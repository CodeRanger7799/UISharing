import React,{Component} from 'react'
import Merchant from './Merchant'
import HomeDashboard from './HomeDashboard'
import {Link} from 'react-router-dom'
import Organization from './Organization' 
import ProcessingGroup from './ProcessingGroup'
import BillingProfile from './BillingProfile'
import FeeProfile from './FeeProfile'
import Presenter from './Presenter'
import Opportunity from './Opportunity'



class Dashboard extends Component{
  constructor(){
    super()
    this.state= {
      showHomeDashboard: true,
      showMerchant: false,
      showProcessingGroup: false,
      showBillingProfile: false,
      showFeeProfile: false,
      showOrganisation: false,
      showPresenter: false,
      showOpportunity: false,
      activeName: 'default',
      previousButtonState: null,
      merchantList: []
    }
    this.hideComponent = this.hideComponent.bind(this);
  }

  componentDidMount(){
    fetch('https://fin1ttl2bg.execute-api.us-east-2.amazonaws.com/dev/listAllProvisionedMerchant')
    .then(response => response.json())
    .then(res => this.setState({merchantList: res}))
  }
  
  hideRestComponent(){
    this.setState({
      showHomeDashboard:false,
      showMerchant:false,
      showBillingProfile:false,
      showFeeProfile: false,
      showProcessingGroup:false,
      showOrganisation: false,
      showPresenter: false,
      showOpportunity: false
    })
    }
  
  lockButton(name){
    var element = document.getElementById(name);
    element.classList.add("selected");
  }
  
  removeLock(name){
    var element = document.getElementById(name);
    element.classList.remove("selected");
  }

  hideComponent(name) {
    if(this.state.previousButtonState){
      this.removeLock(this.state.previousButtonState)
    }
    this.lockButton(name)
    this.hideRestComponent()
    switch (name) {
      case "showOpportunity":
        this.setState({
          showOpportunity: true,
          activeName: 'showOpportunity',
          previousButtonState: 'showOpportunity'
        })
        break;
      case "showMerchant":
        this.setState({ showMerchant: true,
        activeName: 'showMerchant',
        previousButtonState: "showMerchant"
        });
        break;
      case "showProcessingGroup":
        this.setState({ showProcessingGroup: true,
        activeName: 'showProcessingGroup',
        previousButtonState: "showProcessingGroup"
        });
        break;
      case "showBillingProfile":
        this.setState({ showBillingProfile: true,
        activeName: "showBillingProfile",
      previousButtonState: "showBillingProfile" });
        break;
        case "showFeeProfile":
          this.setState({showFeeProfile: true,
          activeName: 'showFeeProfile',
          previousButtonState: "showFeeProfile"
          })
          break;
      case "showOrganisation":
        this.setState({ showOrganisation: true,
        activeName: 'showOrganisation',
      previousButtonState: "showOrganisation"});
        break;
      case "showPresenter":
          this.setState({ showPresenter: true,
          activeName: 'showPresenter',
        previousButtonState: "showPresenter"});
        break;
        default: this.setState({showHomeDashboard: !this.state.showHomeDashboard,
        previousButtonState: ""});
    }
  }
  
  render(){

    const imagePath = {
      showMerchant: 'https://static.thenounproject.com/png/2234223-200.png',
      showProcessingGroup: 'https://static.thenounproject.com/png/28416-200.png',
      showOrganisation: 'https://static.thenounproject.com/png/1130102-200.png',
      showBillingProfile: 'https://static.thenounproject.com/png/28416-200.png',
      showFeeProfile: 'https://static.thenounproject.com/png/28416-200.png',
      showPresenter: 'https://static.thenounproject.com/png/28416-200.png',
      showOpportunity: 'https://static.thenounproject.com/png/92257-200.png'
    }

    const { showHomeDashboard, showMerchant, showProcessingGroup, showBillingProfile, showOrganisation, showFeeProfile, showPresenter, showOpportunity } = this.state;
    const logoutButton = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAMFBMVEXFxcX////CwsLGxsb7+/vT09PJycn19fXq6urb29ve3t7w8PDOzs7n5+f5+fnt7e30nlkBAAAFHUlEQVR4nO2dC5qqMAyFMTwUBdz/bq+VYYrKKJCkOfXmXwHna5uTpA+KwnEcx3Ecx3Ecx3Ecx3Ecx3Ecx3Ecx3Ecx3EcA2iO9cdIc5PUdO257y+BU39u66b4HplE3fk6VIcnqmNfl1+gksr6+iIucjl3WYukor7+re6Hoe1y1UhNO3zUd+fUFRmKpOa0Tt6dY5ubRCrOG/QFLk1WGmnt/JxzykcjdZ/jyxJDLlOV2l36AtcsJJb9boG3YcR3DuqODIE3ztYKPkDdmwRmpUToUaSaq++AvRgZMWbOpbQW8hdCAm8ZDugoikzREdCJ2okJPBx6azFLNOwoOgcxojJ98JkaTSJxMpklKrCAKhZGI0drTY/wU5lXoJYibannV9NYy4oozNEAkPHTjop+DTDxVGkIgYJNoyQQJtiIW+EMjGAjm649AjGIaqswcEFQKJ2QPlJbqytki6ZXAAZRJ52J2McaUowzAfs+uFzrYhnzaapphiPWdaJWShqxjqa6kTTQ205TVbsfMa6htL0iYOsXpJrQjHSmCkv1QGPtiHqlYcQ21Gj7fcDU8xOEUuNgSltPzexh+HqFlanCBHZ4OLhCV+gK/3OF6vWvucLv98MUOY2pwu/PS/+D2qJU7pYGbOvDFDW+bbON9p3o3oRxn0bfLgZTgSn6pSfrtr56qLHemtHPTK2319SzGvtjQ9qeb39WgS66Cm073nd0U1PzDdJCO3Gzn6TKpl9Zq7ujGWsQhlA3NwWIMwG9zM08Y/tBrR9VWeczv5CSQuuUNKIUTk23ZJ5RKfVhjnkXotfWIlgX2BSCDYbZR+QTcLhb3dKZDUY2M0d4KWItwhHRah/zsrOgKw4wycwjcgEVcgQDQo23CqSiWEJkFAfod2oE1uIFdA1OsCPqFXYNTjCfb8Ez+iX2x5sKLlVbhtqdDcar9ZevhnbZxoBUD35k23t0d304LYs1ELVbnfFaZ/REJJX9niP8Q19moZGo3m8XR/yBvOnjFfsXcI2c8ZuNo7WMP5HQh6yRGrlmFOJTnyTcT+zRlqPUBI2gTVWNUzUna1ERgecgF4GpNBQ38jGqxVLzQA1A31Rrhk6Yz9QEh/WND0GnuG9huhiTXJkxfAizTHLr6cbJKN6UCU6x/2DTRE1xEeEXi3O0ZUqBN4nJRzHhFB1JPlFTBZlI2kQ8zc3KJ1Le8DIRmFJiknuVS6RK4Ej/JtBfJErDSzOBiY4wJHX6Z1I4v1GUmdCPNirnLLeg3oJLcbX5PcpHNbRvOa1A956QmRPOUXVF+zkaUJynpkYR0bOMJH2nNej1pqyV/aKkz9jr5yj5vrXXz1F5SQLACiMapmierj2ikLyleKdlA/I/2oFxiglxx9B+mHwz0lf34IZQfhDRhlD6bhvgEAoPYooHkTczSIZTLC+cEExsoNKZiGBiY9cCfo/Y/SjIOBMQizWWTe73CMUasJx7jlD+DdKdWUKoY4PRYFtGpO0G1Lx4RaadgTtJhf4fiGqGIwKWCGuGIwKWqP+7IxYCzygjR9IAO5pC7Da9g70TBVpWRNgFBlgT8RV2WxHbKwJMv4BOaEaYaU2K16yZMN/qgV+G7IWIvwyZCxHeDQMsR8wg0DBDDXB5H2EV+hkEGmaoySHQsEJNFoGGFWrAq98JRhUMX1iMMMqLLEIpK5jCbd4vw9nSt/72lewXiN6jmdjfq8Hdknlk92ZwJnbIMMRM7JBhiFlUFoHd1UWaP1QKsPsHA5mkNB+Smn9JqV3wskatnQAAAABJRU5ErkJggg=="
  
    return (
        <div>
        <div className="split left">
        <div className="topnav">
        <a href = '/Dashboard'>Onboarding system</a>
        {/* <a className='user-icon'><i className='fas'>&#xf406;</i><span class='user-span'>admin</span></a> */}
        {/* <Link to = '/Logout'>Logout</Link> */}
       
       
      </div>
        <div className="centered">
          <img src = {imagePath[this.state.activeName]}  className='dashboard-icon' alt=''/>
          <button id = "showOpportunity" className="dashboard-button" onClick={() =>  this.hideComponent("showOpportunity")}>Opportunity</button>
          <button id = "showMerchant" className="dashboard-button" onClick={() =>  this.hideComponent("showMerchant")}>Merchant</button>
          <button id="showProcessingGroup" className="dashboard-button" onClick={() => this.hideComponent("showProcessingGroup")}>Processing Group</button>
          <button id ="showBillingProfile" className="dashboard-button" onClick={() => this.hideComponent("showBillingProfile")}>Billing Profile</button>
          <button id ="showFeeProfile" className="dashboard-button" onClick={() => this.hideComponent("showFeeProfile")}>Fee Profile</button>
          <button id ="showOrganisation" className="dashboard-button" onClick = {() => this.hideComponent("showOrganisation")}>Organization</button>
          <button id="showPresenter" className="dashboard-button" onClick = {() => this.hideComponent("showPresenter")}>Presenter</button>
        </div>
      </div>

      <div className="split right">
      <div class="navigation">
              <Link className="button-logout" to="/Logout">
                <img className ='logout-img' src={logoutButton} alt='logout-icon'/>
              <div className="logout">LOGOUT</div>
              </Link> 
      </div> 
      <div>
            {showOpportunity && <Opportunity />}
            {showMerchant && <Merchant merchantList = {this.state.merchantList}/>}
            {showProcessingGroup && <ProcessingGroup />}
            {showOrganisation && <Organization />}
            {showBillingProfile && <BillingProfile />}
            {showFeeProfile && <FeeProfile />}
            {showPresenter && <Presenter />}
            {showHomeDashboard && <HomeDashboard />}
            
      <div>
       
      </div>
      </div>
      </div>
      </div>
  )
}
}

export default Dashboard


