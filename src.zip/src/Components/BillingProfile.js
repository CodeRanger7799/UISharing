import React from 'react'
import {Link} from 'react-router-dom'

function BillingProfile(props){
    const handleSearch = () =>
        {
        console.log(document.getElementById('searchParameter').value)
        }

    return (
        <div>
            <div className='container-menu-options'>
                <p> Billing Profile Dashboard</p>
            </div>
        <div class="navbar-merchant">
            <select name='selectParam'>
                <option value = 'Billing Profile ID'>Billing Profile ID</option>
                <option value = 'Organization Id'>Organization Id</option>
                <option value = 'Organization Name'>Organization Name</option>
                <option value = 'Fee Profile Id'>Fee Profile Id</option>
                <option value = 'Fee Profile Name'>Fee Profile Name</option>
            </select>
        <input type="text" placeholder="Search.." name='searchParameter' id='searchParameter'/> 
        <button type="submit" onClick = {handleSearch}><i class="fa fa-search"></i></button>     
        <Link to="/" className='navbar-merchant-Link'>Comprehensive View</Link>
        <Link to="/AddBillingProfile" className='navbar-merchant-Link'>Add</Link>
        {/* <Link to="/" className='navbar-merchant-Link'>Copy</Link> */}
        <Link to="/" className='navbar-merchant-Link'>Edit Basic Details</Link>
    {/*  <div class="dropdown-menu">
       <button class="dropbtn-menu">Accounts
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <Link to="/" className='navbar-merchant-Link'>Edit Fees</Link> */}
     </div>
     <div className="table-container">
  <table>
    <tr>
      <th>Billing Profile ID</th>
      <th>Organization ID</th>
      <th>Organization Name</th>
      <th>Fee Profile ID</th>
      <th>Fee Profile Name</th>
      <th>Acquiring Bank</th>
      <th>Billing Active</th>
    </tr>
    {/* {props.merchantList.map(data => (
       <tr>
       <td>{data.mid}</td>
        <td>{data.merchantName}</td>
        <td>{data.organizationId}</td>
        <td>{data.processingGroupId}</td>
        <td>{data.billingProfileId}</td>
        <td>{data.shortName}</td>
        <td>{data.legalName}</td>
        <td>{data.city}</td>
         <td>{data.state}</td>
        <td>{data.country}</td>
        <td>{data.phoneNumber}</td>
        <td>{data.cardAcceptorTaxId}</td>
        <td>{data.merchantCategoryCode}</td>
        <td>{data.subMerchantName}</td>
        <td>{data.subMerchantUrl}</td>
     </tr>
    ))} */}
    {/* <tr>
        <td><Link to='/'>122334</Link></td>
        <td>Zoopgo</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>KYC</td>
    </tr>
    <tr>
        <td><Link to='/'>990988 </Link></td>
        <td>BigBazar Salt Lake</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>Underwriting</td>
    </tr> */}
  </table>
</div>
    </div>
    )
}

export default BillingProfile