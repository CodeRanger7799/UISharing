import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import { CountryDropdown, RegionDropdown} from 'react-country-region-selector';
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

// CATID: Card Acceptor Tax ID
// MCC: Merchant Category Code
// MTA: Max Transaction Amount
// SMURL: Sub-Merchant URL
// SMN: Sub-Merchant Name


function TestOrganization(props){

    
    // To handle the form submit event 
    const handleForm = data =>{
        const merchant = {
                processingGroupId: 'processingGroupId',
                billingProfileId: "billingProfileId",
                streetAddress2: "Jadavpur",
                organizationId: data.orgId,
                shortName: data.shortName,
                merchantName: data.merchantName,
                legalName: data.legalName,
                streetAddress: data.streetAddress,
                phoneNumber: phone,
                country: country,
                state: region,
                city: data.city,
                postalCode: data.postalCode,
                url: data.URL,
                cardAcceptorTaxId: data.CATID,
                merchantCategoryCode: data.MCC,
                maxTransactionAmount: data.MTA,
                subMerchantUrl: data.SMURL,
                subMerchantName: data.SMN
            }
            props.merchanntAdd(merchant)
        }

        const cancelForm = () => {
            props.merchantCancel()
        }

        const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
        const [phone, setPhone] = useState()
        const [country, setCountry] = useState()
        const [region, setRegion] = useState()

    return (
    <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
                <div className="row">
                    <div className="col-25">
                    <label htmlFor="orgId"><b>Organisation Id</b></label>
                    </div>
                    <div className="col-75">
                     <input type='text' name = 'orgId' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select your organisation id from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.orgId} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="shortName"><b>Short Name</b></label>
                    </div>
                    <div className="col-75">
                     <input type='text' name = 'shortName' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Short Name</span>
                        </div>
                        <ErrorMessage error={errors.shortName} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                       <label htmlFor="merchantName"><b>Full Name</b></label>
                    </div>
                    <div className="col-75">
                     <input type='text' name = 'fullName' ref={register({required:true})}/>
                       <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Full Name</span>
                        </div>
                        <ErrorMessage error={errors.merchantName} />
                    </div>
                </div>

                <div className="row">
                    <div className="col-25">
                         <label htmlFor="type"><b>Type</b></label>
                    </div>
                    <div className="col-75">
                    <select name="type"  ref = {register({required:true})}>
                        <option value = "" disabled selected>Select One...</option>
                         <option value="Merchant"> Merchant </option>
                         <option value="Merchant of Record">Merchant of Record</option>
                         <option value="Payment Proccessor">Payment Proccessor</option>
                         <option value="Presenter">Presenter</option>
                         <option value="Super Organization">Super Organization</option>
                         <option value="Payment Service provider">Payment Service provider</option>
                    </select>  
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select Merchant Category Code</span>
                        </div>   
                        <ErrorMessage error={errors.MCC} />              
                    </div>
                </div>


                
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="LegalName"><b>Legal Name</b></label>
                    </div>
                    <div className="col-75">
                         <input type='text'  name = 'legalName'  ref={register({required:true, minLength:2})}/>
                         <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter legal name of merchant</span>
                        </div>
                        <ErrorMessage error={errors.legalName} />
                    </div>
                </div>
          
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="country"><b>Country</b></label>
                    </div>
                    <div className="col-75">
                        <CountryDropdown value={country} onChange={setCountry} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="state"><b>State</b></label>
                    </div>
                    <div className="col-75">
                        <RegionDropdown country={country} value={region} onChange={setRegion} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="city"><b>City</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'City' name = 'city' ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.city}/>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="postalCode"><b>Postal Code</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Postal Code' name = 'postalCode' ref = {register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.postalCode} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="phoneNumber"><b>Phone Number</b></label>
                    </div>
                    <div className="col-75">
                        <PhoneInput className='phn' international placeholder="Enter phone number" value={phone} onChange={setPhone}/> 
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="URL"><b>URL</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'URL' name = 'URL'  ref={register({required:true, pattern: /^(https?|chrome):\/\/[^\s$.?#].[^\s]*$/gm })}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter URL of merchant</span>
                        </div>
                        <ErrorMessage error={errors.URL} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="CATID"><b>Card Acceptor Tax ID</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'CAT ID' name = 'CATID' ref = {register({required:true})}/> 
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Card Acceptor Tax Id </span>
                        </div>
                        <ErrorMessage error={errors.CATID} /> 
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="MCC"><b>Merchant Category Code</b></label>
                    </div>
                    <div className="col-75">
                    <select name="MCC"  ref = {register({required:true})}>
                        <option value = "" disabled selected>Select One...</option>
                         <option value="0742 : Medical: Veterinary services"> 0742 : Medical: Veterinary services </option>
                         <option value="0763 : Telecom, Utilities & Trades : Agricultural cooperatives">0763 : Telecom, Utilities & Trades : Agricultural cooperatives</option>
                         <option value="0780 : Telecom, Utilities & Trades : Landscaping and horticultural services">0780 : Telecom, Utilities & Trades : Landscaping and horticultural services</option>
                         <option value="1111 : Litle : LITLE">1111 : Litle : LITLE</option>
                         <option value="1520 : Telecom, Utilities & Trades : General contractors - residential and commercial">1520 : Telecom, Utilities & Trades : General contractors - residential and commercial</option>
                         <option value="1711 : Telecom, Utilities & Trades : Heating, plumbing and air-conditioning contractors">1711 : Telecom, Utilities & Trades : Heating, plumbing and air-conditioning contractors</option>
                         <option value="1731 : Telecom, Utilities & Trades : Electrical Contractors">1731 : Telecom, Utilities & Trades : Electrical Contractors</option>
                    </select>  
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select Merchant Category Code</span>
                        </div>   
                        <ErrorMessage error={errors.MCC} />              
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="MTA"><b>Max Transaction Amount</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Max Transaction Amount' name = 'MTA' ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter maximum transaction amount</span>
                        </div>
                        <ErrorMessage error={errors.MTA} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="SMURL"><b>Sub-merchant URL</b></label>
                    </div>
                    <div className="col-75">
                         <input type='text' placeholder = 'Sub-merchant URL' name = 'SMURL' ref={register({required:true})}/>
                         <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter sub-merchant URL</span>
                        </div>
                        <ErrorMessage error={errors.SMURL} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="SMN"><b>Sub Merchant Name</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Sub Merchant Name' name = 'SMN' ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter sub merchant name</span>
                        </div>
                        <ErrorMessage error={errors.SMN} />
                    </div>
                </div>
                <div className="signup-btn">
                     <input type="button" value="Cancel" className='btn1' onClick = {cancelForm}/>
                     <input type="submit" value="Submit" disabled={isSubmitting} className='btn2'/>
                </div>
            </form>
        </div>
    </div>
  )


    }


export default TestOrganization
