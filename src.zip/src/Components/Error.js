import React from 'react'
import {Link} from 'react-router-dom'

function Error(){
    
        return (
            <div>
            <div className = 'error-body'>
                <button className= 'error-btn'> </button>
            </div>
            <Link className = 'add-icon' to = '/'> </Link>
            <p className='add-icon-paragraph'><b> Please click on above icon to try again. </b></p>
            </div>
        )
    
}

export default Error