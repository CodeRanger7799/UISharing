import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import { CountryDropdown, RegionDropdown} from 'react-country-region-selector';
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

function AddProcessingGroup(props){

    const cancelForm = () => {
        props.processingCancel()
    }

    const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
        const [phone, setPhone] = useState()
        const [country, setCountry] = useState()
        const [region, setRegion] = useState()
        const [check, setCheck] = React.useState({
            checkedPrimeEnabled : false
        })

        const [showPrimeOrderSourcesDiv, setPrimeOrderSourcesDiv] = React.useState(true)

        const handleForm = data =>{
            const presenter = {
                    orgId: data.orgId,
                    shortName: data.shortName,
                    presenterType: data.presenterType,
                    formatCode: data.formatCode,
                    transform: data.transform,
                    autoRfr: data.autoRfr,
                    returnCidResponse: data.returnCidResponse,
                    clientCertReq: data.clientCertReq,
                    transactEnabled: check.checkedTransactEnabled,
                    maxThreadOvr: data.maxThreadOvr,
                    maxSessionTps: data.maxSessionTps,
                    lookupTag: data.lookupTag,
                    transConnLimit: data.transConnLimit,
                    clientCertGrp: data.clientCertGrp
                }
               // props.presenterAdd(presenter)
            }

            const handlePrimeEnabled = (event) => {
                setCheck({
                    checkedTransactEnabled: event.target.checked
                })
                if(event.target.checked){
                    hideElement('transConnLimitDiv')
                }
                else{
                    hideElement('lookupDiv')
                }
            }

        const hideElement = (name) => {
            switch(name){
                case 'primeEnabled':
                    setPrimeOrderSourcesDiv(true)
                    break;
                default:
                    setPrimeOrderSourcesDiv(false)    
            }
        }

    return(
        <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="orgId"><b>Organisation Id</b></label>
                    </div>
                    <div className="col-75">
                        <select name="orgId" ref={register({required:true})}>
                        <option value="" disabled selected>Select One...</option>
                            <option value="4:Tid Merchant 10"> 4:Tid Merchant 10 </option>
                            <option value="6:Tid Merchant 11">6:Tid Merchant 11</option>
                            <option value="8:Tid Merchant 12">8:Tid Merchant 12</option>
                            <option value="A merchant-only organisation:25">A merchant-only organisation:25</option>
                            <option value="Amazon Funding Merchant : 103">Amazon Funding Merchant : 103</option>
                            <option value="Amazon : 9999">Amazon : 9999</option>
                            <option value="Auto Account Update : 1250">Auto Account Update : 1250</option>
                        </select>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select your organisation id from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.orgId} />
                    </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="name"><b>Name</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' name = 'name' ref={register({required:true})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter Name</span>
                            </div>
                            <ErrorMessage error={errors.name} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="description"><b>Description</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' name = 'description' ref={register({required:true, minLength:2})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter Description of the processing group</span>
                            </div>
                            <ErrorMessage error={errors.description} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="domCountry"><b>Domicile Country</b></label>
                        </div>
                        <div className="col-75">
                        <CountryDropdown value={country} onChange={setCountry} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="TTD"><b>Telephone Type Default</b></label>
                        </div>
                        <div className="col-75">
                            <select name="TTD"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="Telephone : 1"> Telephone : 1 </option>
                                <option value="Non Auth Secure Ecommerce : 9">Non Auth Secure Ecommerce : 9</option>
                                <option value="Non Authenticated Set-Ecommerce : 6">Non Authenticated Set-Ecommerce : 6</option>
                                <option value="Not Specified : 0">Not Specified : 0</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select Telephone Type Default</span>
                            </div>   
                            <ErrorMessage error={errors.MCC} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="PC"><b>Purchase Currency</b></label>
                        </div>
                        <div className="col-75">
                            <select name="PC"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="US Dollars"> US Dollars </option>
                                <option value="Austrailan Dollars">Austrailan Dollars</option>
                                <option value="EURO">EURO</option>
                                <option value="Japanese Yen">Japanese Yen</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select Purchase Currency</span>
                            </div>   
                            <ErrorMessage error={errors.MCC} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="SC"><b>Settlement Currency</b></label>
                        </div>
                        <div className="col-75">
                            <select name="SC"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="US Dollars"> US Dollars </option>
                                <option value="Austrailan Dollars">Austrailan Dollars</option>
                                <option value="EURO">EURO</option>
                                <option value="Japanese Yen">Japanese Yen</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select Settlement Currency</span>
                            </div>   
                            <ErrorMessage error={errors.MCC} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="LCR"><b>Least Cost routing</b></label>
                        </div>
                        <div className="col-75">
                            <select name="LCR"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="Least Cost : 3"> Least Cost : 3 </option>
                                <option value="Least Cost - Canada : 29">Least Cost - Canada : 29</option>
                                <option value="Least Cost - With MIP : 19">Least Cost - With MIP : 19</option>
                                <option value="Credorax : 30">Credorax : 30</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select Least Cost routing</span>
                            </div>   
                            <ErrorMessage error={errors.LCR} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="SRP"><b>Settlement Routing Profile</b></label>
                        </div>
                        <div className="col-75">
                            <select name="SRP"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="Au only bankcard : 41">Au only bankcard : 41 </option>
                                <option value="AU Only Gateway2 : 40 ">AU Only Gateway2 : 40 </option>
                                <option value="All MOPS Pub Prop Bin : 34">All MOPS Pub Prop Bin : 34</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Settlement Routing Profile</span>
                            </div>   
                            <ErrorMessage error={errors.SRP} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="WG"><b>Workflow Group</b></label>
                        </div>
                        <div className="col-75">
                            <select name="WG"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="Handover Direct Workflow : 16 ">Handover Direct Workflow : 16</option>
                                <option value="Spiegel Worlflow : 21 ">Spiegel Worlflow : 21</option>
                                <option value="Undefined Workflow Group : -1 ">Undefined Workflow Group : -1 </option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Workflow Group</span>
                            </div>   
                            <ErrorMessage error={errors.WG} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="dupeCheckBatches"><b>Dupe Check Batches</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'returnCidResponse'defaultChecked={true}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="expirationdateAdjust"><b>Expiration date Adjust</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'returnCidResponse'defaultChecked={true}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="FDO"><b>Fiscal Day Offset</b></label>
                        </div>
                        <div className="col-75">
                            <select name="FDO"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="-720">-720</option>
                                <option value="-690">-690</option>
                                <option value="-660">-660</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Fiscal Day Offset</span>
                            </div>   
                            <ErrorMessage error={errors.FDO} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="Timezone"><b>Timezone</b></label>
                        </div>
                        <div className="col-75">
                            <select name="Timezone"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="GMT">GMT</option>
                                <option value="America/NY">America/NY</option>
                                <option value="America/Chicago">America/Chicago</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Timezone</span>
                            </div>   
                            <ErrorMessage error={errors.Timezone} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="ac"><b>Aggregate counting</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'returnCidResponse'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="PFT"><b>Payout Funding Type</b></label>
                        </div>
                        <div className="col-75">
                            <select name="PFT"  ref = {register({required:true})}>
                                <option value = "" disabled selected>None...</option>
                                <option value="Managed Payout">Managed Payout</option>
                                <option value="Dynamic Pauout TXN">Dynamic Pauout TXN</option>
                                <option value="Dynamic Pauout FIs">Dynamic Pauout FI</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Payout Funding Type</span>
                            </div>   
                            <ErrorMessage error={errors.Timezone} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="GRD"><b>General Reserve Days</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' name = 'generalreservedays' ref={register({required:true, minLength:2})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter General Reserve Days</span>
                            </div>
                            <ErrorMessage error={errors.GRD} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="RR"><b>Rolling Reverses</b></label>
                        </div>
                        <div className="col-75">
                            <select name="RR"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One...</option>
                                <option value="Auto">Auto</option>
                                <option value="Manual">Manual</option>
                                <option value="Old">Old</option>
                                <option value="None">None</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Rolling Reverses</span>
                            </div>   
                            <ErrorMessage error={errors.RR} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="RFM"><b>Reserve Funding Method</b></label>
                        </div>
                        <div className="col-75">
                            <select name="RFM"  ref = {register({required:true})}>
                                <option value = "Deposits" disabled selected>Deposits</option>
                                <option value="Deposits+Refunds">Deposits+Refunds</option>
                                <option value="Deposits-Refunds">Deposits-Refunds</option>
                            </select>  
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Rolling Reverses</span>
                            </div>   
                            <ErrorMessage error={errors.RR} />              
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="NDEF"><b>Next Day eCheck Funding</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'nextDayecheckfunding'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="ECB"><b>eCheck Custom Billing</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'eCheckCustomBilling'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="ARE"><b>Aperia Reporting Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'aperiaReportingEnabled'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="BRE"><b>Brighterion Reporting Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'brighterionReportingEnabled'defaultChecked={true}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="CDE"><b>Continuous Delivery Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'conDeliveryEnabled'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="FT"><b>Fraud Toolkit</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'fraudToolkit'defaultChecked={false}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="APE"><b>Amazon Pay Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'amazonPayEnabled'  defaultChecked={false} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="PE"><b>Prime Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'primeEnabled' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                        </div>
                    </div>
                    <div className="row-prime-order">
                        <label>Prime Order Sources</label>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="recurring"><b>Recurring</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'recurring' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="installment"><b>Installment</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'installment' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="eCom"><b>eCommerce</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'eCom' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                        <div className="col-25">
                            <label htmlFor="RFM"><b>Prime Message type</b></label>
                        </div>
                        <div className="col-75">
                            <select name="primeMessageType"  ref = {register({required:true})}>
                                <option value = "" disabled selected>Select One..</option>
                                <option value="Billpay">Billpay</option>
                                <option value="eCommerce">eCommerce</option>
                            </select>   
                            <ErrorMessage error={errors.primeMessageType} />              
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="PE"><b>Prime Enabled</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'primeEnabled' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="dyiRoutingEnabled"><b>DYI Routing Enabled</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'dyiRoutingEnabled' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="dyiRoutingEnabled"><b>Prime Auto-Retry Enabled</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'dyiRoutingEnabled' checked = {check.checkedPrimeEnabled} onClick = {handlePrimeEnabled}/>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="vantivExchangeRateAdj"><b>Vantiv Exchange Rate Adjustment</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' name = 'vantivExchangeRateAdj' value='3.85' ref={register({required:true, minLength:2})}/>%
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter Vantiv Exchange Rate Adjustment</span>
                            </div>
                            <ErrorMessage error={errors.vantivExchangeRateAdj} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="processVisaDebitCards"><b>Process Visa Debit Cards</b></label>
                        </div>
                        <div className="col-75">
                            <input type="radio" name = 'processVisaDebitCardsradio' value='Yes' checked></input>
                            <input type="radio" name = 'processVisaDebitCardsradio' value='No'></input>
                            <ErrorMessage error={errors.vantivExchangeRateAdj} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="processMastercardDebitCards"><b>Process MasterCard Debit Cards</b></label>
                        </div>
                        <div className="col-75">
                            <input type="radio" name = 'processMastercardDebitCardsRadio' value='Yes' checked></input>
                            <input type="radio" name = 'processMastercardDebitCardsRadio' value='No'></input>
                            <ErrorMessage error={errors.vantivExchangeRateAdj} />
                        </div>
                    </div>
                    <div className="signup-btn">
                        <input type="button" value="Cancel" className='btn1' onClick = {cancelForm}/>
                        <input type="submit" value="Submit" disabled={isSubmitting} className='btn2'/>
                    </div>
                </form>
                </div>
                </div>
                
    )
}
export default AddProcessingGroup