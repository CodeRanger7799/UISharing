import React from "react";
import { Link } from "react-router-dom";

function FeeProfile(props) {
    const handleSearch = () => {
    console.log(document.getElementById("searchParameter").value);
  };

  return (
    <div>
      <div className="container-menu-options">
        <p> Fee Profile Dashboard</p>
      </div>
      <div class="navbar-merchant">
        <select name="selectParam">
            <option value="Fee Profile Id" selected >Fee Profile ID</option>
            <option value="Fee Profile Name">Fee Profile Name</option>
            <option value="Billing Profile Id">Billing Profile Id</option>
            <option value="Merchant Id">Merchant Id</option>
            <option value="Organization Id">Organization Id</option>
            <option value="Organization Name">Organization Name</option>
        </select>
        <input type="text" placeholder="Search.." name="searchParameter" id="searchParameter"/>
        <button type="submit" onClick={handleSearch}>
          <i class="fa fa-search"></i>
        </button>
        <Link to="/" className="navbar-merchant-Link">Edit Fees</Link>
      </div>
      <div className="table-container">
        <table>
          <tr>
            <th>Fee Profile ID</th>
            <th>Fee Profile Name</th>
            <th>Billing Profile Id</th>
            <th>Merchant Id</th>
            <th>Organization Id</th>
            <th>Organization Name</th>
          </tr>
          <tr>
              <td><Link to='/'>122334</Link></td>
              <td>Payment</td>
              <td>123321</td>
              <td>890987</td>
              <td>1001</td>
              <td>Dominos</td>
          </tr>
          <tr>
              <td><Link to='/'>445566 </Link></td>
              <td>Chargeback</td>
              <td>456654</td>
              <td>452651</td>
              <td>2001</td>
              <td>KFC</td>
          </tr>
        </table>
      </div>
    </div>
  );
}

export default FeeProfile;