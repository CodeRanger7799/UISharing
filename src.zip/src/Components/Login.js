import React from 'react'
import {Link} from 'react-router-dom'
import Title from './Title'

function Login(props){

    function handleSubmit(e)
    {
        e.preventDefault()
        const user = e.target.elements.userName.value
        const pass = e.target.elements.password.value
        
        if(user === 'admin' && pass === 'pass'){
            props.loginSuccess()
        }
    }

    return (
        <div>
        <Title title={'Merchant Onboarding System'}/>
        <div className='login-page'>
        <div className='login-form'>
            <form onSubmit = {handleSubmit}>
                <input type = 'text' placeholder = 'Enter Username' name='userName'/>
                <input type = 'password' placeholder = 'Enter Password' name = 'password'/>
                <button type='submit'> Login </button>
                <p class="message">Having problem logging? <Link to = '/Error'>Contact Support</Link></p>
            </form>
        </div>
        </div>
        </div>
    )
}

export default Login