import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import {useForm} from 'react-hook-form'
import ErrorMessage from '../ErrorMessage'
import { Link } from 'react-router-dom';


function Underwriting(props){

    
    // To handle the form submit event 
    // const handleForm = data =>{
    //     const underwriting = {
    //             dataSecurity: data.dataSecurity,
    //             operatingStatistics: data.operatingStatistics,
    //             orderAndShipments: data.orderAndShipments,
    //             chargebackHandling: data.chargebackHandling,
    //             creditRefundExchangeTransaction: data.creditRefundExchangeTransaction,
    //             guaranteesAndWarrantees: data.guaranteesAndWarrantees,
    //             inventory: data.inventory,
    //             fulfillment: data.fulfillment
    //         }
    //        console.log(underwriting)
    //     }

        const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
        const [merchantBGV,setmerchantBGV] = useState(null)
        const [merchantCHR,setmerchantCHR] = useState(null)



        const handleForm = data => { 
            const formData = new FormData(); 
            formData.append( 
              "BGV", 
              merchantBGV, 
              merchantBGV.name 
            );
            formData.append( 
                "CHR", 
                merchantCHR, 
                merchantCHR.name 
              );
            formData.append("dataSecurity", data.dataSecurity)
            formData.append("operatingStatistics",data.operatingStatistics)
            formData.append("orderAndShipments", data.orderAndShipments)
            formData.append("chargebackHandling",data.chargebackHandling)
            formData.append("creditRefundExchangeTransaction", data.creditRefundExchangeTransaction)
            formData.append("guaranteesAndWarrantees",data.guaranteesAndWarrantees)
            formData.append("inventory", data.inventory)
            formData.append("fulfillment",data.fulfillment)
            for (var pair of formData.entries()) {
                console.log(pair[0]+ ', ' + pair[1]); 
            }
        };


        const onBGVFileChange = event => { 
            setmerchantBGV(event.target.files[0]); 
          };

        const onCHRFileChange = event => { 
            setmerchantCHR(event.target.files[0]); 
          };



    const fileBGVData = () => { 
        if (merchantBGV) { 
          return ( 
            <div> 
              <h2>File Details:</h2> 
              <p>File Name: {merchantBGV.name}</p> 
              <p>File Type: {merchantBGV.type}</p> 
              <p> 
                Last Modified:{" "} 
                {merchantBGV.lastModifiedDate.toDateString()} 
              </p> 
            </div> 
          ); 
        } else { 
          return ( 
            <div> 
              <br /> 
              <h4>Choose before Pressing the Submit button</h4> 
            </div> 
          ); 
        } 
      };

      const fileMerchantCHR = () => { 
        if (merchantCHR) { 
          return ( 
            <div> 
              <h2>File Details:</h2> 
              <p>File Name: {merchantCHR.name}</p> 
              <p>File Type: {merchantCHR.type}</p> 
              <p> 
                Last Modified:{" "} 
                {merchantCHR.lastModifiedDate.toDateString()} 
              </p> 
            </div> 
          ); 
        } else { 
          return ( 
            <div> 
              <br /> 
              <h4>Choose before Pressing the Submit button</h4> 
            </div> 
          ); 
        } 
      };
        


    return (
    <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
            <div className="row">
                    <div className="col-25">
                       <label htmlFor="dataSecurity"><b>Data Security</b></label>
                    </div>
                    <div className="col-75">
                       <input type='text' name = 'dataSecurity' ref={register({required:true})}/>
                       <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Data Security</span>
                        </div>
                        <ErrorMessage error={errors.dataSecurity} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="operatingStatistics"><b>Operating Statistics</b></label>
                    </div>
                    <div className="col-75">
                    <   input type='text' id = "operatingStatistics" name = 'operatingStatistics' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Operating Statistics</span>
                        </div>
                        <ErrorMessage error={errors.operatingStatistics} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="orderAndShipments"><b>Orders & Shipments</b></label>
                    </div>
                    <div className="col-75">
                    <   input type='text' id = "orderAndShipments" name = 'orderAndShipments' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Orders and Shipments</span>
                        </div>
                        <ErrorMessage error={errors.orderAndShipments} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="chargebackHandling"><b>Chargeback Handling</b></label>
                    </div>
                    <div className="col-75">
                    <   input type='text' id = "chargebackHandling" name = 'chargebackHandling' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Chargeback Handling</span>
                        </div>
                        <ErrorMessage error={errors.orderAndShipments} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="creditRefundExchangeTransaction"><b>Credit, Refund & Exchange transactions</b></label>
                    </div>
                    <div className="col-75">
                    <   input type='text' id = "creditRefundExchangeTransaction" name = 'creditRefundExchangeTransaction' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Credit, Refund & Exchange Transactions</span>
                        </div>
                        <ErrorMessage error={errors.creditRefundExchangeTransaction} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="guaranteesAndWarrantees"><b>Guarantees & Warrantees</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text'  name = 'guaranteesAndWarrantees' id="guaranteesAndWarrantees" ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Guarantees & Warrantees </span>
                        </div>
                        <ErrorMessage error={errors.guaranteesAndWarrantees} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="inventory"><b>Inventory</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="inventory"
                        name = 'inventory' ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.inventory} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="fulfillment"><b>Fulfillment</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id = 'fulfillment' 
                        name = 'fulfillment'
                        ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.fulfillment} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="merchantBGVReport"><b>Merchant BGV Report</b></label>
                    </div>
                    <div className="col-75-upload">
                        <input type='file' id="merchantBGVReport"  name = 'merchantBGVReport'  onChange={onBGVFileChange}  ref={register({required:true})}/>
                        {fileBGVData()}
                    </div>
                    <ErrorMessage error={errors.merchantBGVReport} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="merchantCHRReport"><b>Merchant Credit History Report</b></label>
                    </div>
                    <div className="col-75-upload">
                        <input type='file' id="merchantCHRReport"  name = 'merchantCHRReport'  onChange={onCHRFileChange}  ref={register({required:true})}/>
                        {fileMerchantCHR()}
                    </div>
                    <ErrorMessage error={errors.merchantCHRReport} />
                </div>
                <div className="signup-btn">
                    <button className="btn1" ><Link to="/Dashboard" className="link-cancel">Cancel</Link></button>
                     <input type="submit" value="Save" disabled={isSubmitting} className='btn2'/>
                </div>
            </form>
        </div>
    </div>
  )
    }


export default Underwriting
