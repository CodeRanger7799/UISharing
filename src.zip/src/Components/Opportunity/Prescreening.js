import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import { CountryDropdown, RegionDropdown} from 'react-country-region-selector';
import {useForm} from 'react-hook-form'
import ErrorMessage from '../ErrorMessage'
import { Link } from 'react-router-dom';


function Prescreening(props){

    
    // To handle the form submit event 
    const handleForm = data =>{
        const onboarding = {
                legalName: data.legalMerchantName,
                shortName: data.shortName,
                merchantType: data.merchantType,
                merchantCategory: data.merchantCategory,
                phoneNumber: phone,
                email: data.emailAddress,
                legalCity,
                legalCountry,
                legalRegion,
                legalZip,
                legalAddress1,
                legalAddress2,
                billingCity,
                billingCountry,
                billingRegion,
                billingZip,
                billingAddress1,
                billingAdreess2
            }
           console.log(onboarding)
        }

        const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
        const [phone, setPhone] = useState()
        const [legalCountry, setLegalCountry] = useState()
        const [legalRegion, setLegalRegion] = useState()
        const [billingCountry, setBillingCountry] = useState()
        const [billingRegion, setBillingRegion] = useState()
        const [legalAddress1,setLegalAddress1] = React.useState('');
        const [legalAddress2,setLegalAddress2] = React.useState('');
        const [legalCity,setLegalCity] = React.useState('')
        const [legalZip,setLegalZip] = React.useState('')
        const [billingAddress1,setBillingAddress1] = React.useState('');
        const [billingAdreess2,setBillingAddress2] = React.useState('');
        const [billingCity,setBillingCity] = React.useState('');
        const [billingZip, setBillingZip] = React.useState('')
        const [check, setCheck] = React.useState({checkedA: false});

        const handleLegalAddress1 = (event) => {
            setLegalAddress1(event.target.value)
          }
        
          const handleLegalAddress2 = (event) => {
            setLegalAddress2(event.target.value)
          }
        
          const handleLegalCity = (event) => {
            setLegalCity(event.target.value)
          }
        
          const handleLegalZip = (event) => {
            setLegalZip(event.target.value)
          }
        
     
        
          const handleBillingAdress1 = (event) => {
            setBillingAddress1(event.target.value)
          }
        
          const handleBillingAddress2 = (event) => {
            setBillingAddress2(event.target.value)
          }
        
          const handleBillingCity = (event) => {
            setBillingCity(event.target.value)
          }
        
          const handleBillingZip = (event) => {
            setBillingZip(event.target.value)
          }
        
          const clickCheck = (event) => {
            setCheck({
              checkedA: event.target.checked
            })
            if(event.target.checked){
              setLegalToBillingAddress()
            }
            else{
              clearBillingAddress()
            }
          }
        
        const setLegalToBillingAddress = () => {
          setBillingAddress1(legalAddress1)
          setBillingAddress2(legalAddress2)
          setBillingCountry(legalCountry)
          setBillingRegion(legalRegion)
          setBillingCity(legalCity)
          setBillingZip(legalZip)
        }
        
        const clearBillingAddress = () => {
          setBillingAddress1('')
          setBillingAddress2('')
          setBillingCountry('')
          setBillingRegion('')
          setBillingCity('')
          setBillingZip('')
        }
        
    return (
    <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
            <div className="row">
                    <div className="col-25">
                       <label htmlFor="merchantName"><b>Legal Merchant Name</b></label>
                    </div>
                    <div className="col-75">
                       <input type='text' name = 'legalMerchantName' ref={register({required:true, minLength:2})}/>
                       <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter legal name of merchant</span>
                        </div>
                        <ErrorMessage error={errors.legalMerchantName} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="shortName"><b>Short Name</b></label>
                    </div>
                    <div className="col-75">
                    <   input type='text' id = "shortName" name = 'shortName' ref={register({required:true})}/>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Short Name of Merchant</span>
                        </div>
                        <ErrorMessage error={errors.shortName} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                    <label htmlFor="merchantType"><b>Merchant Type</b></label>
                    </div>
                    <div className="col-75">
                    <select id = "merchantType" name="merchantType" ref={register({required:true})}>
                        <option value="" disabled selected>Select One...</option>
                         <option value="PayFac"> PayFac </option>
                         <option value="Direct">Direct</option>
                    </select>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select Merchant type from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.merchantType} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="merchantCategory"><b>Merchant Category</b></label>
                    </div>
                    <div className="col-75">
                    <select name="merchantCategory"  ref = {register({required:true})}>
                        <option value = "" disabled selected>Select One...</option>
                         <option value="Automobiles and Vehicles"> Automobiles and Vehicles </option>
                         <option value="Beauty and Wellness">Beauty and Wellness</option>
                         <option value="BFSI">BFSI</option>
                         <option value="Business Services">Business Services</option>
                         <option value="Cable and Broadband">Cable and Broadband</option>
                         <option value="Corporate Alliance">Corporate Alliance</option>
                         <option value="Devotion">Devotion</option>
                         <option value="Digital Goods">Digital Goods</option>
                         <option value="Education">Education</option>
                         <option value="Entertainment">Entertainment</option>
                         <option value="Event Services">Event Services</option>
                         <option value="Food">Food</option>
                         <option value="Gas and Petrol">Gas and Petrol</option>
                         <option value="Government">Government</option>
                         <option value="Healthcare">Healthcare</option>
                         <option value="Home Services">Home Services</option>
                         <option value="Housing">Housing</option>
                         <option value="LFR and Brands">LFR and Brands</option>
                         <option value="Milk Dairy and Cooperative">Milk Dairy and Cooperative</option>
                         <option value="Transport">Transport</option>
                         <option value="Parking and Tolls">Parking and Tolls</option>
                         <option value="Personal Services">Personal Services</option>
                         <option value="Retail and Shopping">Retail and Shopping</option>
                         <option value="Travel">Travel</option>
                         <option value="Tuition and Classes">Tuition and Classes</option>
                         <option value="Utilities">Utilities</option>
                         <option value="Wholesale Trade and B2B">Wholesale Trade and B2B</option>
                    </select>  
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select Merchant Category</span>
                        </div>   
                        <ErrorMessage error={errors.merchantCategory} />              
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="phoneNumber"><b>Phone Number</b></label>
                    </div>
                    <div className="col-75">
                        <PhoneInput className='phn' international placeholder="Enter phone number" value={phone} onChange={setPhone}/> 
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="URL"><b>Email Address</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Email Address' name = 'emailAddress'  ref={register({required:true, pattern: /^(https?|chrome):\/\/[^\s$.?#].[^\s]*$/gm })}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter Email Address of Merchant</span>
                        </div>
                        <ErrorMessage error={errors.emailAddress} />
                    </div>
                </div>
          
           
                <div className="row">
                    <h3 className="prescreening-banner">Legal Address</h3>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="Legal Address 1"><b>Street Address 1</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="Legal Address 1" placeholder = 'Street Address' 
                        name = 'legalstreetAddress1' value={legalAddress1} onChange={handleLegalAddress1}  ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.legalstreetAddress1} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="Legal Address 2"><b>Street Address 2</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id = 'Legal Address 2' placeholder = 'Street Address' 
                        name = 'legalstreetAddress2' value={legalAddress2} 
                        onChange = {handleLegalAddress2}
                        ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.legalstreetAddress2} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="country"><b>Country</b></label>
                    </div>
                    <div className="col-75">
                        <CountryDropdown value={legalCountry} onChange={setLegalCountry} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="state"><b>State</b></label>
                    </div>
                    <div className="col-75">
                        <RegionDropdown country={legalCountry} value={legalRegion} onChange={setLegalRegion} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="city"><b>City</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id = 'city' value = {legalCity} 
                        onChange = {handleLegalCity}
                        placeholder = 'City' name = 'legalCity' ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.legalCity}/>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="legalpostalCode"><b>Postal Code</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="legalpostalCode" value={legalZip} 
                        onChange = {handleLegalZip}
                         placeholder = 'Postal Code' name = 'legalPostalCode' ref = {register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.legalPostalCode} />
                </div>
                <div className="row">
                <div className="col-25">
                         <label htmlFor="checkBox"><b></b></label>
                    </div>
                    <div className="col-75">
                        <input type='checkbox' name = 'checkLegalSameToBilling' checked={check.checkedA} onClick={clickCheck}/>Please click if Legal Address is same as Billing Address
                    </div>
                </div>

                <div className="row">
                    <h3 className="prescreening-banner">Billing Address</h3>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor=" Billing Street Address 1"><b>Street Address 1</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id=" Billing Street Address 1" value={billingAddress1}
                        onChange = {handleBillingAdress1}
                        placeholder = 'Street Address' name = 'billingstreetAddress1'  ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.billingstreetAddress1} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="Billing Street Address 2"><b>Street Address 2</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="Billing Street Address 2" 
                        value = {billingAdreess2} onChange = {handleBillingAddress2}
                        placeholder = 'Street Address' name = 'billingstreetAddress2'  ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.billingstreetAddress2} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="country"><b>Country</b></label>
                    </div>
                    <div className="col-75">
                        <CountryDropdown value={billingCountry} onChange={setBillingCountry} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="state"><b>State</b></label>
                    </div>
                    <div className="col-75">
                        <RegionDropdown country={billingCountry} value={billingRegion} onChange={setBillingRegion} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="billingcity"><b>City</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="billingcity" value = {billingCity} onChange= {handleBillingCity} 
                        placeholder = 'City' name = 'billingcity' ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.billingcity}/>
                </div>
                <div className="row">
                    <div className="col-25">
                         <label htmlFor="billingpostalCode"><b>Postal Code</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="billingpostalCode" 
                        value = {billingZip} onChange = {handleBillingZip}
                        placeholder = 'Postal Code' name = 'billingpostalCode' ref = {register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.billingpostalCode} />
                </div>
                <div className="signup-btn">
                    <button className="btn1" ><Link to="/Dashboard" className="link-cancel">Cancel</Link></button>
                     <input type="submit" value="Save" disabled={isSubmitting} className='btn2'/>
                </div>
            </form>
        </div>
    </div>
  )


    }


export default Prescreening
