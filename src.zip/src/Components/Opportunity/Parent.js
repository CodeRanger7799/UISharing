
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Prescreening from './Prescreening'
import KYC from './KYC'
import Underwriting from './Underwriting'
import Certification from './Certification'





const useStyles = makeStyles((theme) => ({
  appBar: {
    position: 'relative',
    backgroundColor: '#ace1af'
  },
  layout: {
    width: 'auto',
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    [theme.breakpoints.up(1000 + theme.spacing(2) * 2)]: {
      width: '100%',
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2),
    [theme.breakpoints.up(1000 + theme.spacing(3) * 2)]: {
      marginTop: theme.spacing(6),
      marginBottom: theme.spacing(6),
      padding: theme.spacing(3),
    },
    backgroundColor: '#f2f2f2'
  },
  stepper: {
    padding: theme.spacing(3, 0, 5),
    backgroundColor: '#f2f2f2'
  },
  buttons: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));




const steps = ['Pre-Screening', 'KYC', 'Underwriting','Certification'];



function Parent(props) {
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);

  const handleNext = () => {
    if(activeStep === 1 || activeStep === 2){
      setActiveStep(activeStep + 0.5)
    }
    else{
      setActiveStep(activeStep + 1);
    }
  };


  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };


  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return <Prescreening />;
      case 1:
        return <KYC />;
      case 2:
        return <Underwriting />;
      case 3:
          return <Certification />;
      default:
        return null;
    }
  }

 

  return (
    <React.Fragment>
   
      <main className={classes.layout}>
        <Paper className={classes.paper}>
          <Typography component="h1" variant="h4" align="center">
            
          </Typography>
          <Stepper activeStep={activeStep} className={classes.stepper}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          <React.Fragment>
            {activeStep === steps.length ? (
              <React.Fragment>
                <Typography variant="h5" gutterBottom>
                  Congratulations! All steps done.
                </Typography>
                <Typography variant="subtitle1">
                  We have emailed all necessary details.
                </Typography>
              </React.Fragment>
            ) : activeStep === 1.5 ? 
                 ( <React.Fragment>
                <Typography variant="h5" gutterBottom>
                  Thank you for entering all details.
                </Typography>
                <Typography variant="subtitle1">
                  Your submission number is #2001539. We will email your KYC confirmation, and will
                  send you a link for completing the further steps.
                </Typography>
              </React.Fragment>)
             : (activeStep === 2.5 ? 
             (
              <React.Fragment>
              <Typography variant="h5" gutterBottom>
                Thank you for providing all details.
              </Typography>
              <Typography variant="subtitle1">
                Based on the details provided the underwriter shall verify the Merchant. We will email the result and the next steps that needs to be done.
              </Typography>
            </React.Fragment>)
              :
              (<React.Fragment>
                {getStepContent(activeStep)}
                <div className={classes.buttons}>
                  {activeStep === 1 && (
                    <Button onClick={handleBack} className={classes.button}>
                      Back
                    </Button>
                  )}
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleNext}
                    className={classes.button}
                  >
                  {activeStep === 0 ? 'Next' : 'Submit'}
                  </Button>
                </div>
              </React.Fragment>)
             )}
          </React.Fragment>
        </Paper>
       
      </main>
    </React.Fragment>
  );
}

export default Parent