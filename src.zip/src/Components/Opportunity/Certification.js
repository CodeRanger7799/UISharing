import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Grid from '@material-ui/core/Grid';

const useStyles = makeStyles((theme) => ({
  listItem: {
    padding: theme.spacing(),
  },
  total: {
    fontWeight: 700,
  },
  title: {
    marginTop: theme.spacing(2),
  },
}));

function Certification() {

    const displayInfo = [
        { info: 'Organization ID', value: 'Amazon Funding Merchant : 103' },
        { info: 'Merchant ID', value: '0014928' },
        { info: 'Merchant Name', value: 'VectorShop' },
        { info: 'Merchant Reporting Platform', value: 'https://onboarding.com' }
      ];

      const apiKey = '709a2466-5b23-454b-9a98-ccf14bf7d83c';
      const apiSecretKey = '0e57619b-fabb-4556-bed2-b930716656fa15dc4090-f68a-4da7-a82a-52477b747b3c';

  const classes = useStyles();

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Note the following information and proceed
      </Typography>
      <List disablePadding>
        {displayInfo.map((item) => (
          <ListItem className={classes.listItem} key={item.info}>
            <ListItemText primary={item.info}/>
            <Typography variant="body2">{item.value}</Typography>
          </ListItem>
        ))}
      </List>
      <Grid item xs={12} sm={6}>
          <Typography variant="h6" gutterBottom className={classes.title}>
            API Credentials
          </Typography>
        <Typography gutterBottom>Key: {apiKey}</Typography>
        <Typography gutterBottom>Secret Key: {apiSecretKey}</Typography>
        </Grid>
    </React.Fragment>
  );
}

export default Certification