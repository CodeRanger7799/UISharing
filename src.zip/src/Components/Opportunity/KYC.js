import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import {useForm} from 'react-hook-form'
import ErrorMessage from '../ErrorMessage'
import {Link} from 'react-router-dom'

function KYC(props){
    const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
    const [selectedFile,setSelectedFile] = useState(null)

    const onFileChange = event => { 
        setSelectedFile(event.target.files[0]); 
      };

    const handleForm = data => { 
        const formData = new FormData(); 
        formData.append( 
          "document", 
          selectedFile, 
          selectedFile.name 
        );
        formData.append("authorizedSignatory", data.authorizedSignatory)
        formData.append("authorizedEmail",data.authorizedEmail)
        // Details of the uploaded file 
        for (var pair of formData.entries()) {
            console.log(pair[0]+ ', ' + pair[1]); 
        }
      // Request made to the backend api 
    //   // Send formData object 
    //   axios.post("api/uploadfile", formData); 
    };

    const fileData = () => { 
        if (selectedFile) { 
          return ( 
            <div> 
              <h2>File Details:</h2> 
              <p>File Name: {selectedFile.name}</p> 
              <p>File Type: {selectedFile.type}</p> 
              <p> 
                Last Modified:{" "} 
                {selectedFile.lastModifiedDate.toDateString()} 
              </p> 
            </div> 
          ); 
        } else { 
          return ( 
            <div> 
              <br /> 
              <h4>Choose before Pressing the Submit button</h4> 
            </div> 
          ); 
        } 
      };

    return (
    <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
            <div className="row">
                    <div className="col-25">
                        <label htmlFor="document"><b>Document</b></label>
                    </div>
                    <div className="col-75-upload">
                        <input type='file' id="document"  name = 'document' placeholder="Upload document" onChange={onFileChange}  ref={register({required:true})}/>
                        {fileData()}
                    </div>
                    <ErrorMessage error={errors.document} />
                </div>
       
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="authorizedSignatory"><b>Name of Authorized Signatory</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="authorizedSignatory"  name = 'authorizedSignatory'  ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.authorizedSignatory} />
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="authorizedEmail"><b>Signatory Authority Email ID</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' id="authorizedEmail" name = 'authorizedEmail'  ref={register({required:true})}/>
                    </div>
                    <ErrorMessage error={errors.authorizedEmail} />
                </div>
            
                <div className="signup-btn">
                     <button className="btn1" ><Link to="/Dashboard" className="link-cancel">Cancel</Link></button>
                     <input type="submit" value="Save" disabled={isSubmitting} className='btn2'/>
                </div>
            </form>
        </div>
    </div>
  )


    }


export default KYC
