import React from 'react'
import {Link} from 'react-router-dom'

function Organization(props){
  const handleSearch = () =>
  {
    console.log(document.getElementById('searchParameter').value)
  }

return (
    <div>
        <div className='container-menu-options'>
         <p> Organization Dashboard</p>
     </div>
     <div class="navbar-merchant">
        <select name='selectParam'>
        <option value = 'Organization Id' selected disabled>Organization ID</option>
        <option value = 'Organization Id'>Full Name</option>
        </select>
     <input type="text" placeholder="Search.." name='searchParameter' id='searchParameter'/> 
     <button type="submit" onClick = {handleSearch}><i class="fa fa-search"></i></button>     
     <Link to="/" className='navbar-merchant-Link'>Comprehensive View</Link>
     <Link to="/AddOrganization" className='navbar-merchant-Link'>Add</Link>
     <Link to="/" className='navbar-merchant-Link'>Edit Basic Details </Link>
     {/* <div class="dropdown-menu">
       <button class="dropbtn-menu">Edit Processing Groups
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Edit Merchants
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Features
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Payment Service Provider
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div> */}
     </div>
     <div className="table-container">
  <table>
    <tr>
      <th>Organiation ID</th>
      <th>Short Name</th>
      <th>Full Name</th>
      <th>Type</th>
      <th>Parent Oraganization ID</th>
      <th>Acuiring Contract Owner</th>
      <th>Acquirer Fee Level</th>
    </tr>
    {/* {props.merchantList.map(data => (
       <tr>
       <td>{data.mid}</td>
        <td>{data.merchantName}</td>
        <td>{data.organizationId}</td>
        <td>{data.processingGroupId}</td>
        <td>{data.billingProfileId}</td>
        <td>{data.shortName}</td>
        <td>{data.legalName}</td>
        <td>{data.city}</td>
         <td>{data.state}</td>
        <td>{data.country}</td>
        <td>{data.phoneNumber}</td>
        <td>{data.cardAcceptorTaxId}</td>
        <td>{data.merchantCategoryCode}</td>
        <td>{data.subMerchantName}</td>
        <td>{data.subMerchantUrl}</td>
     </tr>
    ))} */}
    {/* <tr>
        <td><Link to='/'>122334</Link></td>
        <td>Zoopgo</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>KYC</td>
    </tr>
    <tr>
        <td><Link to='/'>990988 </Link></td>
        <td>BigBazar Salt Lake</td>
        <td>India</td>
        <td>merchantCategoryCode</td>
        <td>subMerchantName</td>
        <td>Underwriting</td>
    </tr> */}
  </table>
   </div>
    </div>
)
}

 

export default Organization