import React from 'react'
import {Link} from 'react-router-dom'

function Organization(props){
  const handleSearch = () =>
  {
    console.log(document.getElementById('searchParameter').value)
  }

return (
    <div>
        <div className='container-menu-options'>
         <p> Organization Dashboard</p>
     </div>
     <div class="navbar-merchant">
        <select name='selectParam'>
        <option value = 'Organization Id' selected disabled>Organization ID</option>
        <option value = 'Organization Id'>Full Name</option>
        </select>
     <input type="text" placeholder="Search.." name='searchParameter' id='searchParameter'/> 
     <button type="submit" onClick = {handleSearch}><i class="fa fa-search"></i></button>     
     <Link to="/" className='navbar-merchant-Link'>Comprehensive View</Link>
     <Link to="/AddOrganization" className='navbar-merchant-Link'>Add</Link>
     <Link to="/" className='navbar-merchant-Link'>Edit Basic Details </Link>
     {/* <div class="dropdown-menu">
       <button class="dropbtn-menu">Edit Processing Groups
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Edit Merchants
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Features
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Payment Service Provider
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div> */}
     </div>
     <div className="table-container">
  <table>
   <thead>
    <tr>
      <th>Organiation ID</th>
      <th>Short Name</th>
      <th>Full Name</th>
      <th>Type</th>
      <th>Parent Oraganization ID</th>
      <th>Acuiring Contract Owner</th>
      <th>Acquirer Fee Level</th>
    </tr>
    </thead>
    <tbody>
      {
        props.organizationList.map(data => (
          <tr key={data.organizationId}>
            <td><Link to ='/'>{data.organizationId}</Link></td>
            <td>{data.organizationShortName}</td>
            <td>{data.organizationFullName}</td>
            <td>{data.subType}</td>
            <td>{data.parentOrganizationId}</td>
            <td>{data.acquringContractOwner}</td>
            <td>{data.acquirerFeeLevel}</td>
          </tr>
        ))
      }
    </tbody>
   
  </table>
   </div>
    </div>
)
}

 

export default Organization