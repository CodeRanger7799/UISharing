import React,{Component} from 'react'
import {Route} from 'react-router-dom'
import Title from './Title'
import Test from './TestmerchantSignup'
import Success from './Success'
import Error from './Error'
import MerchantSignup from './MerchantSignup'
import Dashboard from './Dashboard'
import Login from './Login'
import Logout from './Logout'
import AddBillingProfile from './AddBillingProfile'
import AddOrganization from './AddOrganization'
import PresenterAdd from './PresenterAdd'
import MerchantSingle from './MerchantSingle'


 


class Main extends Component{

    constructor(){
        super()
        this.state = {
            addMsg: ''
        }
    }

    MerchantAdded(merchant)
    {
        var proxyUrl = 'https://cors-anywhere.herokuapp.com/'
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(merchant)
         };
        fetch(proxyUrl + 'https://fin1ttl2bg.execute-api.us-east-2.amazonaws.com/dev/addNewMerchantRequest',requestOptions)
        .then(response => response.json())
        .then(data => this.setState({
            addMsg: data
        }))
      
    }

    OrganizationAdded(orgs){
        console.log(orgs)
    }

    BillingProfileAdded(billingprofile){
        console.log(billingprofile)
    }

    PresenterAdded(presenter)
    {
        console.log(presenter)
    }

    render()
    {
        return(
            <div>
                <Route path = '/MerchantSignup' render = {
                    ({history}) => {
                        return(
                        <div>
                            <Title title={'Add Merchant'}/>
                            <MerchantSignup merchanntAdd = {
                                (merchant) =>{
                                    this.MerchantAdded(merchant)
                                    history.push('/Success')
                                }
                            }   merchantCancel = {
                                () => {
                                    history.push('/Dashboard')
                                }
                            }/>
                            </div>)
                    }
                }/>

                <Route path='/Success' render = {
                    () => {
                        return (
                        <div>
                        <Title title={this.state.addMsg}/>
                        <Success />
                        </div>)
                    }
                }/>

                <Route path='/Error' render = {
                    () => {
                        return (
                            <div>
                            <Title title = {'Sorry, Some Unexpected Error Occured.'} />
                            <Error />
                            </div>
                        )
                    }
                } />

                <Route path= '/Test' render = {
                 ({history}) => {
                     return(
                         <div>
                             <Title title={'Add Merchant'}/>
                             <Test merchanntAdd = {
                                 (p) =>{
                                     this.MerchantAdded(p)
                                     history.push('/Success')
                                 }
                             }/>
                             </div>
                     )
                 }
                }/>

                <Route path = '/Dashboard' render =
                 {
                     ({history}) => {
                        return (
                            <div>
                                <Dashboard {...this.props} history = {history} />
                                </div>
                        )
                     }
                 }/>
                <Route exact path= '/' render = {
                ({history}) => {
                    return (
                        <Login loginSuccess = {
                        () => {
                             history.push('/Dashboard')
                        }
                        }
                        />
                    )
                }    
                }
                />


                <Route path = '/AddBillingProfile' render = {
                ({history}) => {
                    return(
                    <div>
                        <Title title={'Add Billing Profile'}/>
                        <AddBillingProfile addBillProf = {
                            (billingprofile) =>{
                                this.BillingProfileAdded(billingprofile)
                                history.push('/Success')
                            }
                        }   cancelBillProf = {
                            () => {
                                history.push('/Dashboard')
                            }
                        }/>
                    </div>)
                    }
                    }/>

                <Route path = '/AddOrganization' render = {
                ({history}) => {
                    return(
                    <div>
                        <Title title={'Add Organization'}/>
                        <AddOrganization addOrg = {
                            (orgs) =>{
                                this.OrganizationAdded(orgs)
                                history.push('/Success')
                            }
                        }   cancelOrg = {
                            () => {
                                history.push('/Dashboard')
                            }
                        }/>
                    </div>)
                }
                }/>

                <Route path='/Logout' render = {
                () => {
                    return (<div>
                         <Title title = {'Logout Success'} />
                         <Logout />
                        </div>)
                   
                }
                }/>

                <Route path = '/PresenterAdd' render = {
                ({history}) => {
                    return(
                    <div>
                        <Title title={'Add Presenter'}/>
                        <PresenterAdd presenterAdd = {
                            (presenter) =>{
                                this.PresenterAdded(presenter)
                                history.push('/Success')
                            }
                        }   presenterCancel = {
                            () => {
                                history.push('/Dashboard')
                            }
                        }/>
                        </div>)
                }
                }/>

                <Route path="/MerchantSingle/:mid" render = {
                    (params) => {
                        return (
                            <div>
                                <MerchantSingle {...params} />
                                </div>
                        )
                    }
                } />
            </div>
        )
    }
}

export default Main

