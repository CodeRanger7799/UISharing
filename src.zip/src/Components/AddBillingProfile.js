import React from 'react'
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

 

function AddBillingProfile(props){
    const handleForm = data =>{
        const billingprofile = {
            orgId: data.orgId,
            billProfId: data.billProfId,
            billProfName: data.billProfName,
            credoraxWeelySettlement: check.checkedcredoraxWeelySettlement,
            floatDays: data.floatDays,
            bankClosedFundTranferNoDelay: data.bankClosedFundTranferNoDelay,
            minTransferAmount: data.minTransferAmount,
            acquiringBank: data.acquiringBank,
            billingActive: check.checkedBillingActive,
            cardAccptTaxIdToChangeFanf: data.cardAccptTaxIdToChangeFanf
        }
        props.addBillProf(billingprofile)
    }
    const cancelForm = () => {
        props.cancelBillProf()
    }
    const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
    const [check, setCheck] = React.useState({
        checkedBillingActive: true,
        checkedcredoraxWeelySettlement: false
    })

    const handleBillingActive = (event) =>{
       setCheck({
           checkedBillingActive: event.target.checked
       })
    }

    const handleCredoraxWeelySettlement = (event) => {
        setCheck({
            checkedcredoraxWeelySettlement: event.target.checked
        })
    }

    return(
    <div>
        <div className='container'>
            <form onSubmit= {handleSubmit(handleForm)}>
                  <div className="row">
                    <div className="col-25">
                    <label htmlFor="orgId"><b>Organisation Id</b></label>
                    </div>
                    <div className="col-75">
                    <select name="orgId" ref={register({required:true})}>
                        <option value="" disabled selected>Select One...</option>
                         <option value="4:Tid Merchant 10"> 4:Tid Merchant 10 </option>
                         <option value="6:Tid Merchant 11">6:Tid Merchant 11</option>
                         <option value="8:Tid Merchant 12">8:Tid Merchant 12</option>
                         <option value="A merchant-only organisation:25">A merchant-only organisation:25</option>
                         <option value="Amazon Funding Merchant : 103">Amazon Funding Merchant : 103</option>
                         <option value="Amazon : 9999">Amazon : 9999</option>
                         <option value="Auto Account Update : 1250">Auto Account Update : 1250</option>
                    </select>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select your organisation id from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.orgId} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="billProfId"><b>Billing Profile Id</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Billing Profile Id' name = 'billProfId' ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter billing profile id</span>
                        </div>
                        <ErrorMessage error={errors.billProfId} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="billProfName"><b>Billing Profile Name</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' placeholder = 'Billing Profile Name' name = 'billProfName' ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter billing profile name</span>
                        </div>
                        <ErrorMessage error={errors.billProfName} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="credoraxWeelySettlement"><b>Credorax weekly Settlement</b></label>
                    </div>
                    <div className="col-75">
                        <input type='checkbox' name = 'credoraxWeelySettlement' checked = {check.checkedcredoraxWeelySettlement} onClick = {handleCredoraxWeelySettlement}/>
                        <ErrorMessage error={errors.credoraxWeelySettlement} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="floatDays"><b>Float Days</b></label>
                    </div>
                    <div className="col-75">
                    <select name="floatDays" ref={register({required:true})}>
                        <option value="0" >0</option>
                         <option value="1">1 </option>
                         <option value="2">2</option>
                         <option value="3">3</option>
                         <option value="4">4</option>
                    </select>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select days from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.floatDays} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="bankClosedFundTranferNoDelay"><b>Bank Closed fund Transfer No Delay</b></label>
                    </div>
                    <div className="col-75">
                        <input type='checkbox' name = 'bankClosedFundTranferNoDelay'/>
                        <ErrorMessage error={errors.bankClosedFundTranferNoDelay} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="minTransferAmount"><b>Minimum Transfer Amount</b></label>
                    </div>
                    <div className="col-75">
                        <input type='text' name = 'minTransferAmount' defaultValue = "10.0" ref={register({required:true})}/>
                        <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Enter min transfer amt</span>
                        </div>
                        <ErrorMessage error={errors.minTransferAmount} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="acquiringBank"><b>Acquiring Bank</b></label>
                    </div>
                    <div className="col-75">
                    <select name="acquiringBank" ref={register({required:true})}>
                        <option value="" disabled selected>Select One...</option>
                        <option value="0" >Vantiv Core</option>
                         <option value="1">Fifth Third </option>
                         <option value="2">Citizens</option>
                         <option value="3">Peoples Trust Canadian</option>
                         <option value="4">Credorax</option>
                         <option value="4">Digital river</option>
                    </select>
                    <div class="tooltip"><i class='fas fa-info-circle'></i>
                            <span class="tooltiptext">Select AcquiringBank from the drop down menu</span>
                        </div>
                        <ErrorMessage error={errors.acquiringBank} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="billingActive"><b>Billing Active</b></label>
                    </div>
                    <div className="col-75">
                        <input type='checkbox' name = 'billingActive' checked = {check.checkedBillingActive} onClick={handleBillingActive}/>
                        <ErrorMessage error={errors.billingActive} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="cardAccptTaxIdToChangeFanf"><b>Card Acceptor Tax Ids To Change FANF (Enter ecah on a new line)</b></label>
                    </div>
                    <div className="col-75">
                        <textarea name="cardAccptTaxIdToChangeFanf" rows="4" cols="50"></textarea>
                        <ErrorMessage error={errors.cardAccptTaxIdToChangeFanf} />
                    </div>
                </div>
                <div className="signup-btn">
                     <input type="button" value="Cancel" className='btn1' onClick = {cancelForm}/>
                     <input type="submit" value="Submit" disabled={isSubmitting} className='btn2'/>
                </div>
            </form>
        </div>
    </div>
    )
}

 

export default AddBillingProfile