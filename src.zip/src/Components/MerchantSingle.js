import React, { Component } from 'react'

class MerchantSingle extends Component {
    constructor()
    {
        super()
        this.state = {
            merchant: {}
        }
    }

    componentDidMount(){
        fetch(`https://fin1ttl2bg.execute-api.us-east-2.amazonaws.com/dev/getProvisionedMerchant/${this.props.match.params.mid}`)
        .then(response => response.json())
        .then(data => this.setState({
            merchant: data
        }))
    }

    render() {
        console.log(this.props)
        return (
            <div className="container-table">   
                <table className="table-single">
                    <tbody>
                    <tr>
                        <th>Merchant ID</th>
                        <td>{this.state.merchant.mid}</td>
                    </tr>
                    <tr>
                        <th>Merchant Name</th>
                        <td>{this.state.merchant.merchantName}</td>
                    </tr>
                    <tr>
                        <th>Processing Group ID</th>
                        <td>{this.state.merchant.processingGroupId}</td>
                    </tr>
                    <tr>
                        <th>Billing Profile ID</th>
                        <td>{this.state.merchant.billingProfileId}</td>
                    </tr>
                    <tr>
                        <th>Short Name</th>
                        <td>{this.state.merchant.shortName}</td>
                    </tr>
                    <tr>
                        <th>Legal Name</th>
                        <td>{this.state.merchant.legalName}</td>
                    </tr>
                    <tr>
                        <th>Country</th>
                        <td>{this.state.merchant.country}</td>
                    </tr>
                    <tr>
                        <th>State</th>
                        <td>{this.state.merchant.state}</td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td>{this.state.merchant.city}</td>
                    </tr>
                    <tr>
                        <th>Postal Code</th>
                        <td>{this.state.merchant.postalCode}</td>
                    </tr>
                    <tr>
                        <th>Phone Number</th>
                        <td>{this.state.merchant.phoneNumber}</td>
                    </tr>
                    <tr>
                        <th>Street Address</th>
                        <td>{this.state.merchant.streetAddress}{','}{this.state.merchant.streetAddress2}</td>
                    </tr>
                    <tr>
                        <th>URL</th>
                        <td>{this.state.merchant.url}</td>
                    </tr>
                    <tr>
                        <th>Card Acceptor Tax ID</th>
                        <td>{this.state.merchant.cardAcceptorTaxId}</td>
                    </tr>
                    <tr>
                        <th>Merchant Catergory Code</th>
                        <td>{this.state.merchant.merchantCategoryCode}</td>
                    </tr>
                    <tr>
                        <th>Max Transaction Amount</th>
                        <td>{this.state.merchant.maxTransactionAmount}</td>
                    </tr>
                    <tr>
                        <th>Sub Merchant Url</th>
                        <td>{this.state.merchant.subMerchantUrl}</td>
                    </tr>
                    <tr>
                        <th>Sub Merchant Name</th>
                        <td>{this.state.merchant.subMerchantName}</td>
                    </tr>
                    </tbody>
                </table>
                <div className="signup-btn">
                {/* <input type="button" value="Back" className='btn1' onClick={() => this.props.history.push('/Dashboard')}/> */}
                <input type="submit" value="Edit"  className='btn2'/>
                </div>   
            </div>    
        )
    }
}

export default MerchantSingle
