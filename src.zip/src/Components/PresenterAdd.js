import React from 'react'
import 'react-phone-number-input/style.css'
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

function PresenterAdd(props){
     const viewNote = () => {
        console.log(document.getElementById('formatCode').value)
        if(document.getElementById('formatCode').value === 'Phoenix XML Spec'){
            document.getElementById('note1').innerHTML = "Note: Once format code is server as XML 10 it cannot be changed to a earlier version";
            document.getElementById('note1').style.fontWeight = 'bold';
            document.getElementById('note2').innerHTML = "Note: Once format code is server as ECOMXML format it cannot be changed later";
            document.getElementById('note2').style.fontWeight = 'bold';
        }
        else{
            document.getElementById('note1').innerHTML = "";
            document.getElementById('note2').innerHTML = "";
        }
    }
    const handleForm = data =>{
        const presenter = {
                orgId: data.orgId,
                shortName: data.shortName,
                presenterType: data.presenterType,
                formatCode: data.formatCode,
                transform: data.transform,
                autoRfr: data.autoRfr,
                returnCidResponse: check.returnCidResponse,
                clientCertReq: check.clientCertReq,
                transactEnabled: check.checkedTransactEnabled,
                maxThreadOvr: data.maxThreadOvr,
                maxSessionTps: data.maxSessionTps,
                lookupTag: data.lookupTag,
                transConnLimit: data.transConnLimit,
                clientCertGrp: data.clientCertGrp
            }
            props.presenterAdd(presenter)
        }
        const cancelForm = () => {
            props.presenterCancel()
        }
        const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
        const [check, setCheck] = React.useState({
            returnCidResponse: true,
            clientCertReq: false,
            checkedTransactEnabled : false
        })
        const [showlookupDiv, setLookupDiv] = React.useState(true)
        const [showtransConnLimitDiv, settransConnLimitDiv] = React.useState(true)

        const hideElement = (name) => {
            switch(name){
                case 'lookupDiv':
                    setLookupDiv(true)
                    settransConnLimitDiv(false)
                    break;
                case 'transConnLimitDiv':
                    settransConnLimitDiv(true)
                    setLookupDiv(false)
                break;
                default:
                    setLookupDiv(true)
                    settransConnLimitDiv(true)    
            }
        }
        const handleTransactEnabled = (event) => {
            setCheck({
                checkedTransactEnabled: event.target.checked
            })
            if(event.target.checked){
                hideElement('transConnLimitDiv')
            }
            else{
                hideElement('lookupDiv')
            }
        }
        const handleReturnCidResponse = (event) =>{
            setCheck({
                returnCidResponse: event.target.checked
            })
         }
         const handleClientCertReq = (event) => {
             setCheck({
                clientCertReq: event.target.checked
             })
         }

        return (
            <div>
                <div className='container'>
                    <form onSubmit= {handleSubmit(handleForm)}>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="orgId"><b>Organisation Id</b></label>
                        </div>
                        <div className="col-75">
                            <select name="orgId" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="4:Tid Merchant 10"> 4:Tid Merchant 10 </option>
                                <option value="6:Tid Merchant 11">6:Tid Merchant 11</option>
                                <option value="8:Tid Merchant 12">8:Tid Merchant 12</option>
                                <option value="A merchant-only organisation:25">A merchant-only organisation:25</option>
                                <option value="Amazon Funding Merchant : 103">Amazon Funding Merchant : 103</option>
                                <option value="Amazon : 9999">Amazon : 9999</option>
                                <option value="Auto Account Update : 1250">Auto Account Update : 1250</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select your organisation id from the drop down menu</span>
                            </div>
                            <ErrorMessage error={errors.orgId} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="shortName"><b>Short Name</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' placeholder = 'Short Name' name = 'shortName' ref={register({required:true})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter Short Name</span>
                            </div>
                            <ErrorMessage error={errors.shortName} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="presenterType"><b>Presenter Type</b></label>
                        </div>
                        <div className="col-75">
                            <select name="presenterType" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="Batch">Batch </option>
                                <option value="Chargeback Feed">Chargeback Feed</option>
                                <option value="Online">Online</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select the Presenter Type from the drop down menu</span>
                            </div>
                                <ErrorMessage error={errors.presenterType} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="formatCode"><b>Format Code</b></label>
                        </div>
                        <div className="col-75">
                            <select name="formatCode" id = 'formatCode' onChange = {viewNote}>
                                <option value = "" selected disabled>Select format code</option>
                                <option value="Phoenix XML Spec">Phoenix XML Spec</option>
                                <option value="PayPal Format">PayPal Format</option>
                                <option value="MasterCard Format">MasterCard Format</option>
                                <option value="Visa Format">Visa Format</option>
                            </select>
                            <p id= "note1"></p>
                            <p id="note2"></p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="transform"><b>Transform</b></label>
                        </div>
                        <div className="col-75">
                            <select name="transform" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="Chargeback Feed V1 transform : 22">Chargeback Feed V1 transform : 22 </option>
                                <option value="Chargeback Feed V2 transform : 23">Chargeback Feed V2 transform : 23</option>
                                <option value="Chargeback Feed V2.1 transform : 24">Chargeback Feed V2.1 transform : 24</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select Transform from the drop down menu</span>
                            </div>
                                <ErrorMessage error={errors.transform} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="autoRfr"><b>Auto RFR</b></label>
                        </div>
                        <div className="col-75">
                            <select name="autoRfr" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="Normal Behaviour">Normal Behaviour </option>
                                <option value="Automatically set Auth Sessions to RFR NEEDED after completion">
                                    Automatically set Auth Sessions to RFR NEEDED after completion</option>
                                <option value="RFR NEEDED for all sessions (auth and settlement)">
                                    RFR NEEDED for all sessions (auth and settlement)</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Select the Auto RFR from the drop down menu</span>
                            </div>
                                <ErrorMessage error={errors.autoRfr} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="returnCidResponse"><b>Return CID Response</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'returnCidResponse'checked = {check.returnCidResponse} onClick={handleReturnCidResponse}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="maxThreadOvr"><b>Max Thread Override</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text'placeholder = 'Max Thread Overrride' name = 'maxThreadOvr' />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="maxSessionTps"><b>Max Session TPS</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' placeholder = 'Max Session TPS' name = 'maxSessionTps' />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="transactEnabled"><b>Transact Enabled</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'transactEnabled' checked = {check.checkedTransactEnabled} onClick = {handleTransactEnabled}/>
                        </div>
                    </div>
                   {showlookupDiv && (<div className="row" id ="lookupDiv">
                        <div className="col-25">
                            <label htmlFor="lookupTag"><b>Lookup Tag</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' placeholder = 'Lookup Tag' name = 'lookupTag' ref={register({lookupTagRequired:true})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                <span class="tooltiptext">Enter Lookup tag With respect to Transact Enabled</span>
                            </div>
                            <ErrorMessage error={errors.lookupTag} />
                        </div>
                    </div>) }
                    {showtransConnLimitDiv &&(<div className="row" id ="transConnLimitDiv">
                        <div className="col-25">
                            <label htmlFor="transConnLimit"><b>Transact Connection Limit</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' placeholder = 'Transact Connection Limit' name = 'transConnLimit' />
                        </div>
                    </div>)}
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="clientCertReq"><b>Client Certificate Required</b></label>
                        </div>
                        <div className="col-75">
                            <input type='checkbox' name = 'clientCertReq'checked = {check.clientCertReq} onClick={handleClientCertReq}/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label htmlFor="clientCertGrp"><b>Client Certificate Group (OU=)</b></label>
                        </div>
                        <div className="col-75">
                            <input type='text' placeholder = 'Client Certificate Group' name = 'clientCertGrp' />
                        </div>
                    </div>
                    <div className="signup-btn">
                        <input type="button" value="Cancel" className='btn1' onClick = {cancelForm}/>
                        <input type="submit" value="Submit" disabled={isSubmitting} className='btn2'/>
                    </div>
                    </form>
                </div>
            </div>
        )
}

export default PresenterAdd