import React from 'react'
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

 

function AddOrganization(props){

    const handleForm = data =>{
        const orgs = {
            orgId: data.orgId,
            shortName: data.shortName,
            fullName: data.fullName,
            type: data.type,
            subType: data.subType,
            amexPSP: data.amexPSP,
            amexMI: data.amexMI,
            acqConOwner: data.acqConOwner,
            parentOrgId: data.parentOrgId,
            feeRounding: data.feeRounding,
            depositCredlimt: data.depositCredlimt,
            refundCredlimt: data.refundCredlimt,
            orphanrefundCredLimt: data.orphanrefundCredLimt,
            suppMCBusinsServArIR: data.suppMCBusinsServArIR,
            suppQueryTransaction: data.suppQueryTransaction,
            salesforceId: data.salesforceId,
            enableLogicalBackendTyping: data.enableLogicalBackendTyping,
            startMultiSiteday: data.startMultiSiteday,
            maxNumCategoryNodes: data.maxNumCategoryNodes,
            slaReportFrequency: data.slaReportFrequency,
            pazienEnableIndicator: data.pazienEnableIndicator,
            ssoPazien: data.ssoPazien,
            acquirerFeeLevel: data.acquirerFeeLevel,
            nssReportRemoveComma: data.nssReportRemoveComma
        }
            props.addOrg(orgs)
        }

    const cancelForm = () => {
        props.cancelOrg()
    }

    const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();
    return(
            <div>
                <div className='container'>
                    <form onSubmit= {handleSubmit(handleForm)}>
                        <div className="row">
                            <div className="col-25">
                            <label htmlFor="orgId"><b>Organization Id</b></label>
                            </div>
                            <div className="col-75">
                            <input type='text' placeholder = 'Org ID' name = 'orgId' ref={register({required:true})}/>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select your organization id from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.orgId} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="shortName"><b>Short Name</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Short Name' name = 'shortName' ref={register({required:true})}/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Enter Short Name</span>
                                </div>
                                <ErrorMessage error={errors.shortName} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="fullName"><b>Full Name</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text'  placeholder = 'Full Name' name = 'fullName' ref={register({required:true})}/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Enter Full Name</span>
                                </div>
                                <ErrorMessage error={errors.fullName} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="type"><b>Type</b></label>
                            </div>
                            <div className="col-75">
                            <select name="type" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="Merchant">Merchant </option>
                                 <option value="Merchant of Record">Merchant of Record</option>
                                 <option value="Payment Proccessor">Payment Proccessor</option>
                                 <option value="Presenter">Presenter</option>
                                 <option value="Super Organization">Super Organization</option>
                                 <option value="Payment Service provider">Payment Service provider</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select type from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.type} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="subType"><b>Sub Type</b></label>
                            </div>
                            <div className="col-75">
                            <select name="subType" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                 <option value="Merchant">Merchant </option>
                                 <option value="Merchant of Record">Merchant of Record</option>
                                 <option value="Payment Proccessor">Payment Proccessor</option>
                                 <option value="Presenter">Presenter</option>
                                 <option value="Super Organization">Super Organization</option>
                                 <option value="Payment Service provider">Payment Service provider</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select sub type from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.subType} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="amexPSP"><b>Amex Payment Service Provider</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'amexPSP'/>
                                <ErrorMessage error={errors.amexPSP} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="amexMI"><b>Amex Marketing Indicator</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'amexMI'/>
                                <ErrorMessage error={errors.amexMI} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="acqConOwner"><b>Acuiring Contract Owner</b></label>
                            </div>
                            <div className="col-75">
                            <select name="acqConOwner" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                 <option value="Litle">Litle </option>
                                 <option value="Vantiv">Vantiv</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select acquiring owner from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.acqConOwner} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="parentOrgId"><b>Parent Organization ID</b></label>
                            </div>
                            <div className="col-75">
                            <select name="parentOrgId" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                 <option value="parent org id">parent org id </option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select parent org id from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.parentOrgId} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="feeRounding"><b>Fee Rounding</b></label>
                            </div>
                            <div className="col-75">
                            <select name="feeRounding" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                 <option value="Bankers_agg round half even at journal entry level">Bankers_agg round half even at journal entry level</option>
                                 <option value="Bankers_txn round half even at transactional level">Bankers_txn round half even at transactional level</option>
                            </select>
                            <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Select fee rounding from the drop down menu</span>
                                </div>
                                <ErrorMessage error={errors.feeRounding} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="depositCredlimt"><b>Deposit Credit Limit (in USD including foreign currency)</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Deposit Credit Limit' name = 'depositCredlimt' ref={register({required:true})}/>
                                <ErrorMessage error={errors.depositCredlimt} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="refundCredlimt"><b>Refund Credit Limit (in USD including foreign currency)</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Refund Credit Limit' name = 'refundCredlimt' ref={register({required:true})}/>
                                <ErrorMessage error={errors.refundCredlimt} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="orphanrefundCredLimt"><b>Orphan Refund Credit Limit (in USD including foreign currency)</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Orphan Refund Credit Limit' name = 'orphanrefundCredLimt' ref={register({required:true})}/>
                                <ErrorMessage error={errors.orphanrefundCredLimt} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="suppMCBusinsServArIR"><b>Support Master Card Business Service Arrangement Interchange rates</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'suppMCBusinsServArIR'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">This is very rare. Need to have Arrangement with issuing bank first.</span>
                                </div>
                                <ErrorMessage error={errors.suppMCBusinsServArIR} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="suppQueryTransaction"><b>Support Query Transactions</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'suppQueryTransaction'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Enable Query Organisation for query transaction</span>
                                </div>
                                <ErrorMessage error={errors.suppQueryTransaction} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="salesforceId"><b>Salesforce ID</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Salesforce ID' name = 'salesforceId' ref={register({required:true})}/>
                                <ErrorMessage error={errors.salesforceId} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="enableLogicalBackendTyping"><b>Enable Logical back End Typing</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'enableLogicalBackendTyping'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Enable Logical back End Typing</span>
                                </div>
                                <ErrorMessage error={errors.enableLogicalBackendTyping} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="startMultiSiteday"><b>Start Multi Site day</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' placeholder = 'Multi Site Date' name = 'startMultiSiteday' ref={register({required:true})}/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">MM/DD/YYYY format</span>
                                </div>
                                <ErrorMessage error={errors.startMultiSiteday} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="maxNumCategoryNodes"><b>Maximum No. of Category Nodes</b></label>
                            </div>
                            <div className="col-75">
                                <input type='text' name = 'maxNumCategoryNodes' ref={register({required:true})}/>
                                <ErrorMessage error={errors.maxNumCategoryNodes} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="slaReportFrequency"><b>SLA Report Frequency</b></label>
                            </div>
                            <div className="col-75">
                            <select name="slaReportFrequency" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="None">None</option>
                                 <option value="Monthly">Monthly</option>
                                 <option value="Quarterly">Quarterly</option>
                                 <option value="All">All</option>
                            </select>
                                <ErrorMessage error={errors.slaReportFrequency} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="pazienEnableIndicator"><b>Pazien Enable Indicator</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'pazienEnableIndicator'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Checking this option will make the Organization Pazien Enabled</span>
                                </div>
                                <ErrorMessage error={errors.pazienEnableIndicator} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="ssoPazien"><b>SSO Pazien</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'ssoPazien'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Checking this option will make the Organization as SSO Pazien Enabled</span>
                                </div>
                                <ErrorMessage error={errors.ssoPazien} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="acquirerFeeLevel"><b>Acquirer Fee Level</b></label>
                            </div>
                            <div className="col-75">
                            <select name="acquirerFeeLevel" ref={register({required:true})}>
                                <option value="" disabled selected>Select One...</option>
                                <option value="default">default</option>
                                 <option value="L1">L1</option>
                                 <option value="L2">L2</option>
                                 <option value="L3">L3</option>
                                 <option value="L4">L4</option>
                            </select>
                                <ErrorMessage error={errors.acquirerFeeLevel} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-25">
                                <label htmlFor="nssReportRemoveComma"><b>Net Settled Sales Report Remove Comma</b></label>
                            </div>
                            <div className="col-75">
                                <input type='checkbox' name = 'nssReportRemoveComma'/>
                                <div class="tooltip"><i class='fas fa-info-circle'></i>
                                    <span class="tooltiptext">Checking this option will rempove the comma from the data when generating Net Settled Sales Report</span>
                                </div>
                                <ErrorMessage error={errors.nssReportRemoveComma} />
                            </div>
                        </div>
                        <div className="signup-btn">
                             <input type="button" value="Cancel" className='btn1' onClick = {cancelForm}/>
                             <input type="submit" value="Submit" disabled={isSubmitting} className='btn2'/>
                        </div>
                    </form>          
                </div>
            </div>
            )
         
         }
         
        export default AddOrganization
        